package com.example.dmoverlay

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.net.Uri
import android.os.Environment
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Button
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

data class OverlayLabel(var rect: RectF, var text: String)

class EditorOverlayView(context: Context) : View(context) {
    private val labels = mutableListOf<OverlayLabel>()
    private val ocrBoxes = mutableListOf<Pair<RectF, String>>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var startX = 0f
    private var startY = 0f
    private var current: RectF? = null
    private var drawing = false
    private var selectedColor = Color.rgb(45, 45, 50)

    init { setLayerType(View.LAYER_TYPE_SOFTWARE, null) }

    fun setOcrResults(texts: ArrayList<String>, coords: FloatArray) {
        ocrBoxes.clear()
        val count = minOf(texts.size, coords.size / 4)
        for (i in 0 until count) {
            val r = RectF(coords[i*4], coords[i*4+1], coords[i*4+2], coords[i*4+3])
            ocrBoxes.add(r to texts[i])
        }
        invalidate()
        Toast.makeText(context, "Found $count text regions. Tap a box to replace visually.", Toast.LENGTH_LONG).show()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        // OCR suggestions are dashed outlines only; they do not alter source pixels.
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 3f; paint.color = Color.YELLOW
        paint.pathEffect = DashPathEffect(floatArrayOf(10f, 8f), 0f)
        ocrBoxes.forEach { canvas.drawRect(it.first, paint) }
        paint.pathEffect = null
        labels.forEach { drawLabel(canvas, it) }
        current?.let {
            paint.style = Paint.Style.STROKE; paint.color = Color.CYAN; paint.strokeWidth = 4f
            canvas.drawRect(it, paint)
        }
        paint.style = Paint.Style.FILL
        paint.color = Color.WHITE; paint.textSize = 30f
        canvas.drawText("DM Overlay • tap OCR box or drag a new area", 24f, height - 28f, paint)
    }

    private fun drawLabel(canvas: Canvas, label: OverlayLabel) {
        paint.style = Paint.Style.FILL; paint.color = selectedColor
        canvas.drawRoundRect(label.rect, 12f, 12f, paint)
        paint.color = Color.WHITE; paint.textSize = 28f
        val maxWidth = label.rect.width() - 20f
        val words = label.text.split(" ")
        var line = ""; var y = label.rect.top + 34f
        for (word in words) {
            val next = if (line.isEmpty()) word else "$line $word"
            if (paint.measureText(next) > maxWidth && line.isNotEmpty()) {
                canvas.drawText(line, label.rect.left + 10f, y, paint); line = word; y += 32f
            } else line = next
        }
        if (line.isNotEmpty()) canvas.drawText(line, label.rect.left + 10f, y, paint)
        paint.textSize = 12f
        paint.color = Color.YELLOW
        canvas.drawText("EDITED PREVIEW", label.rect.left + 8f, label.rect.bottom - 6f, paint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                val hit = ocrBoxes.lastOrNull { it.first.contains(event.x, event.y) }
                if (hit != null) { showTextDialog(hit.first, hit.second); return true }
                startX = event.x; startY = event.y
                current = RectF(startX, startY, startX, startY); drawing = true
                invalidate(); return true
            }
            MotionEvent.ACTION_MOVE -> if (drawing) {
                current = RectF(minOf(startX,event.x), minOf(startY,event.y), maxOf(startX,event.x), maxOf(startY,event.y))
                invalidate(); return true
            }
            MotionEvent.ACTION_UP -> if (drawing) {
                drawing = false
                val r = current ?: return true
                current = null
                if (r.width() > 40 && r.height() > 24) showTextDialog(r, "")
                invalidate(); return true
            }
        }
        return true
    }

    private fun showTextDialog(rect: RectF, existing: String) {
        val input = EditText(context).apply { setText(existing); hint = "Replacement preview text" }
        val colors = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        val dialogLayout = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 8)
            addView(input)
            val row = LinearLayout(context)
            listOf(Color.rgb(45,45,50), Color.WHITE, Color.rgb(95,65,125), Color.rgb(35,90,70)).forEach { c ->
                val b = Button(context).apply { text = "●"; setTextColor(c); setOnClickListener { selectedColor = c } }
                row.addView(b)
            }
            addView(row)
        }
        AlertDialog.Builder(context).setTitle("Visual replacement")
            .setView(dialogLayout)
            .setPositiveButton("Apply") { _, _ ->
                labels.add(OverlayLabel(RectF(rect), input.text.toString()))
                invalidate()
            }.setNegativeButton("Cancel", null).show()
    }

    fun clearAll() { labels.clear(); invalidate() }
}
