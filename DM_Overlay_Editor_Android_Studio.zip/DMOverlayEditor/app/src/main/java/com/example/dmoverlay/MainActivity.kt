package com.example.dmoverlay

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val captureRequest = 501
    private val overlayRequest = 502

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
        }
        layout.addView(TextView(this).apply {
            text = "DM Overlay Editor\n\nA local visual editor for screen mockups and personal previews. It does not edit Instagram messages."
            textSize = 19f
        })
        layout.addView(Button(this).apply {
            text = "1. Enable floating overlay"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivityForResult(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")), overlayRequest)
                } else startCaptureConsent()
            }
        })
        layout.addView(Button(this).apply {
            text = "2. Start editor (after permission)"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "Enable overlay permission first", Toast.LENGTH_LONG).show()
                } else startCaptureConsent()
            }
        })
        layout.addView(TextView(this).apply {
            text = "\nHow to use:\n• Open Instagram after starting the editor.\n• Tap the floating DM bubble.\n• Drag to draw a cover area, then enter replacement text.\n• Use Scan to detect visible text boxes.\n• Export creates a labelled overlay preview, not an original Instagram screenshot."
            textSize = 15f
        })
        setContentView(layout)
    }

    private fun startCaptureConsent() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), captureRequest)
    }

    @Deprecated("Activity result API kept simple for this starter project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == overlayRequest && Settings.canDrawOverlays(this)) startCaptureConsent()
        if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
            val capture = Intent(this, CaptureService::class.java).apply {
                putExtra("resultCode", resultCode)
                putExtra("resultData", data)
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(capture) else startService(capture)
            val overlay = Intent(this, OverlayService::class.java)
            startService(overlay)
            Toast.makeText(this, "Editor started. Switch to Instagram.", Toast.LENGTH_LONG).show()
        }
    }
}
