package com.example.dmoverlay

import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var editor: EditorOverlayView? = null
    private val scanReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val data = intent ?: return
            val labels = data.getStringArrayListExtra("labels") ?: arrayListOf()
            val rects = data.getFloatArrayExtra("rects") ?: floatArrayOf()
            editor?.setOcrResults(labels, rects)
        }
    }

    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val filter = IntentFilter("com.example.dmoverlay.OCR_RESULTS")
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(scanReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(scanReceiver, filter)
        }
        showBubble()
    }

    private fun params(type: Int) = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
        type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.END; x = 18; y = 180 }

    private fun showBubble() {
        bubble = TextView(this).apply {
            text = "DM"
            textSize = 16f
            setTextColor(0xffffffff.toInt())
            setPadding(22, 16, 22, 16)
            setBackgroundColor(0xff8b5cf6.toInt())
            setOnClickListener { toggleEditor() }
        }
        wm.addView(bubble, params(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY))
    }

    private fun toggleEditor() {
        if (editor != null) {
            wm.removeView(editor); editor = null
            return
        }
        editor = EditorOverlayView(this)
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(editor, p)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onDestroy() {
        try { unregisterReceiver(scanReceiver) } catch (_: Exception) {}
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        editor?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
