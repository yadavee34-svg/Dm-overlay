package com.example.dmoverlay

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var busy = false
    private lateinit var worker: Handler

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val channel = "dm_overlay_capture"
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(channel, "Screen text detection", NotificationManager.IMPORTANCE_LOW))
            val notification = Notification.Builder(this, channel)
                .setContentTitle("DM Overlay Editor").setContentText("Screen text detection is ready")
                .setSmallIcon(android.R.drawable.ic_menu_edit).build()
            startForeground(71, notification)
        }
        val code = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED) ?: return START_NOT_STICKY
        val data = intent.getParcelableExtra<Intent>("resultData") ?: return START_NOT_STICKY
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(code, data)
        val dm = resources.displayMetrics
        val thread = HandlerThread("dm-ocr").apply { start() }
        worker = Handler(thread.looper)
        reader = ImageReader.newInstance(dm.widthPixels, dm.heightPixels, PixelFormat.RGBA_8888, 2)
        display = projection?.createVirtualDisplay("DMOverlayOCR", dm.widthPixels, dm.heightPixels,
            dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, worker)
        reader?.setOnImageAvailableListener({ source ->
            if (busy) { source.acquireLatestImage()?.close(); return@setOnImageAvailableListener }
            val image = source.acquireLatestImage() ?: return@setOnImageAvailableListener
            busy = true
            runOcr(image)
        }, worker)
        return START_STICKY
    }

    private fun runOcr(media: Image) {
        val frame = InputImage.fromMediaImage(media, 0)
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        recognizer.process(frame).addOnSuccessListener { result ->
            val labels = ArrayList<String>()
            val coords = ArrayList<Float>()
            result.textBlocks.forEach { block ->
                block.lines.forEach { line ->
                    val b = line.boundingBox ?: return@forEach
                    labels.add(line.text)
                    coords.add(b.left.toFloat()); coords.add(b.top.toFloat())
                    coords.add(b.right.toFloat()); coords.add(b.bottom.toFloat())
                }
            }
            val broadcast = Intent("com.example.dmoverlay.OCR_RESULTS").apply {
                setPackage(packageName)
                putStringArrayListExtra("labels", labels)
                putExtra("rects", coords.toFloatArray())
            }
            sendBroadcast(broadcast)
        }.addOnCompleteListener {
            media.close(); busy = false; recognizer.close()
        }
    }

    override fun onDestroy() {
        display?.release(); reader?.close(); projection?.stop()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
