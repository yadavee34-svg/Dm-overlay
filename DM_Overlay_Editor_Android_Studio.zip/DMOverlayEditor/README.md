# DM Overlay Editor (Android)

A Kotlin starter project for Android 8.0+ (designed/tested target: Android 12). It provides:
- A floating `DM` bubble using Android's overlay permission.
- Manual drag-to-select rectangles and replacement text labels.
- OCR detection using Google ML Kit Text Recognition from a user-approved MediaProjection session.
- OCR boxes are suggestions; tap a detected box to create a local visual replacement label.

## Important limitation
This is a local visual mockup/editor. It does **not** edit Instagram's message database, send messages, or change what another person sees. Screen overlays and OCR may not align perfectly on every device. Use only for personal mockups or clearly labelled edited previews. Do not present altered conversations as authentic evidence.

## Build
1. Install Android Studio (Giraffe or newer) and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Let Gradle sync and download dependencies (internet required).
4. Connect the POCO M2 Pro with USB debugging enabled, or use an Android 12 emulator.
5. Press Run. On the phone, allow the screen-capture prompt and grant **Display over other apps** permission.
6. Return to Instagram. Tap the floating purple `DM` bubble.
7. Drag anywhere to draw a manual cover area, or tap a yellow OCR outline to use detected text as the starting text.
8. Type replacement text and tap Apply. Tap the bubble again to close the editor.

## Current MVP scope / known limitations
- OCR scans the captured display after screen-capture consent; Android displays its normal screen-sharing indicator.
- OCR results are screen-coordinate suggestions; status/navigation bars or display scaling can cause small offsets.
- The editor currently draws local cover-and-text labels. A full composited screenshot exporter, font picker, undo/redo stack, and persistent project storage are not included in this starter version.
- The overlay's touch layer intercepts touches while open. Close it by tapping the floating bubble after closing the overlay (if the bubble is obscured, stop the app from its launcher / Android app settings).
- For a production release, add a persistent notification with a Stop action, runtime notification permission handling on Android 13+, and device-specific testing.

## Dependencies
- Android Gradle Plugin 8.6.1
- Kotlin 2.0.21
- ML Kit Text Recognition 16.0.1
